# CHANGELOG.md

## 1.0.0 (Dec 18, 2018)

First release
